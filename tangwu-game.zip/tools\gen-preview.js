'use strict';
// 生成 public/preview.html：离线 UI 预览页（所有手势 + 全部技能卡牌），用于视觉验收
const fs = require('fs');
const path = require('path');
const { SKILLS } = require('../skills');

const groups = Object.keys(SKILLS).map((d) => ({
  d,
  skills: SKILLS[d].map((s) => ({ id: s.id, name: s.name, desc: s.desc, star: !!s.star, isDigit: !!s.isDigit })),
}));

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>唐五 UI 预览</title>
<link rel="stylesheet" href="style.css">
<style>
  body { padding: 26px; display: block; }
  h1 { margin-bottom: 6px; }
  .section { margin: 22px 0 10px; padding-bottom: 6px; border-bottom: 1px solid var(--line); }
  .row { display: flex; flex-wrap: wrap; gap: 16px; }
  .grid-preview { display: grid; grid-template-columns: repeat(auto-fill, minmax(185px, 1fr)); gap: 10px; }
  .demo-card { background: var(--panel); border: 1px solid var(--line); border-radius: 14px; padding: 12px; display: flex; align-items: center; gap: 12px; }
</style>
</head>
<body>
<h1>🖐 唐五 UI 预览</h1>
<div class="hint">手势 0–11（能量手蓝徽章 / 技能手紫徽章）</div>
<div class="section"></div>
<div class="row" id="hands"></div>
<div class="section">对局界面（模拟）</div>
<section id="game">
  <div class="player-card" id="mock-opp"></div>
  <div class="mid">
    <div class="banner myturn">🎯 你的回合</div>
    <div class="log" id="mock-log"></div>
  </div>
  <div class="player-card active" id="mock-me"></div>
  <div class="controls" id="mock-controls"></div>
</section>
<div class="section">全部技能卡牌</div>
<div id="groups"></div>
<script src="ui.js"></script>
<script>
const groups = ${JSON.stringify(groups)};
const handsEl = document.getElementById('hands');
for (let d = 0; d <= 11; d++) {
  handsEl.innerHTML += '<div class="hand-box ' + (d % 2 ? 'skill' : 'energy') + '">' + handSVG(d) + '<div class="hand-digit ' + (d % 2 ? 'skill' : 'energy') + '">' + d + '</div></div>';
}
// ---- 对局模拟 ----
function mockPlayer(p, label, ctrl) {
  const buffs = p.buffs.map((b) => '<span class="buff" data-key="' + b[0] + '" title="' + b[2] + '">' + b[1] + '·' + b[2] + '</span>').join('');
  const hpPct = Math.max(0, Math.min(100, (p.hp / 30) * 100));
  const hpCls = p.hp > 15 ? 'good' : (p.hp > 7 ? 'mid' : 'low');
  return '<div class="p-head"><span class="p-name">' + label + ' · ' + p.name + (ctrl ? ' 🧠' : '') + '</span>'
    + '<span class="energy-badge" title="实际能量">⚡ ' + p.energy + '</span></div>'
    + '<div class="hp-row"><div class="hp-bar"><div class="hp-fill ' + hpCls + '" style="width:' + hpPct + '%"></div></div><span class="hp-num">' + p.hp + '</span></div>'
    + '<div class="hands">'
    + '<div class="hand-box energy" title="能量手">' + handSVG(p.e) + '<div class="hand-digit energy">' + p.e + '</div></div>'
    + '<div class="hand-box skill" title="技能手">' + handSVG(p.s) + '<div class="hand-digit skill">' + p.s + '</div></div>'
    + '</div><div class="buffs">' + buffs + '</div>';
}
document.getElementById('mock-opp').innerHTML = mockPlayer({ name: '小明', e: 8, s: 6, hp: 14, energy: 9, buffs: [['qibu', '七步', '每回合-4血'], ['freeze', '冰封', '剩1回合']] }, '对手', false);
document.getElementById('mock-me').innerHTML = mockPlayer({ name: '我', e: 3, s: 6, hp: 19, energy: 11, buffs: [['qianghua', '强化', '永久'], ['wudi', '无敌', '已就绪']] }, '我', false);
document.getElementById('mock-log').innerHTML = [
  ['nrg', '小明 回合开始：能量 +1（当前 9）'],
  ['sys', '冰！：小明 被冰封2回合'],
  ['dmg', '小烈焰：对 小明 造成3点伤害'],
  ['heal', '急救箱：回复10点生命'],
  ['sys', '强化生效（永久）'],
].map(([c, t]) => '<div class="log-line ' + c + '">' + t + '</div>').join('');
const mockSkills = groups.find((g) => g.d === '6').skills;
let mc = '<div class="prompt">技能手 = <b>6</b>，费用 <b>6</b> 能量（当前 11）</div><div class="skill-grid">';
mockSkills.forEach((sk, i) => { mc += skillCardHTML(sk, 6, true, 'data-mock="' + i + '"'); });
mc += '</div><button class="pass-btn">空过（结束回合）</button>';
document.getElementById('mock-controls').innerHTML = mc;
const gEl = document.getElementById('groups');
for (const g of groups) {
  let cards = '';
  g.skills.forEach((sk, i) => { cards += skillCardHTML(sk, g.d, true, 'data-skill="' + i + '"'); });
  gEl.innerHTML += '<div class="section">数字 ' + g.d + '</div><div class="grid-preview">' + cards + '</div>';
}
</script>
</body>
</html>`;

fs.writeFileSync(path.join(__dirname, '..', 'public', 'preview.html'), html, 'utf8');
console.log('已生成 public/preview.html，共', groups.length, '组技能');
